package com.saisankar.smsfms.faculty;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.saisankar.smsfms.R;

public class FacultyHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_home);
    }
}
