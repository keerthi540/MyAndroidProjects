package com.example.prohelpr.users;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.prohelpr.R;

public class UsersHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_home);
    }
}