package com.example.prohelpr.workers;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.prohelpr.R;

public class WorkerHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_worker_home);
    }
}